<?php return array (
  'contact-form' => 'App\\Http\\Livewire\\ContactForm',
  'container-with-tabs' => 'App\\Http\\Livewire\\ContainerWithTabs',
  'nav-bar' => 'App\\Http\\Livewire\\NavBar',
);