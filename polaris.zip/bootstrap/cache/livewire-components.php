<?php return array (
  'container-with-tabs' => 'App\\Http\\Livewire\\ContainerWithTabs',
  'nav-bar' => 'App\\Http\\Livewire\\NavBar',
);