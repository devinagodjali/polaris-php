<section class="Flex JustifyContent-center MarginTop-2xlarge">
    <section class="HomeChoose Flex Flex-column AlignItems-center BorderBox">
        <div class="Montserrat-bold Font-24 TextAlign-center Padding Margin MobileChoose"> Why Choose Polaris </div>
        <hr class="BorderBottom" />


        <section class="Width Flex JustifyContent-between MarginTop-2xlarge">
            <div class="HomeChoose-image">
                <img class="Choose" src="/assets/png/chair-placeholder.png" alt="Chair Placeholder">
            </div>
            <div class="HomeChoose-image">
                <img class="Choose" src="/assets/png/chair-placeholder.png" alt="Chair Placeholder">
            </div>
            <div class="HomeChoose-image">
                <img class="Choose" src="/assets/png/chair-placeholder.png" alt="Chair Placeholder">
            </div>
        </section>

        <section class="Width Flex JustifyContent-around MarginTop-2xlarge MarginBottom-xlarge">
            <div class="Font-24 Montserrat-bold FontChoose">
                Ergonomic
            </div>
            <div class="Font-24 Montserrat-bold FontChoose">
                Comfort
            </div>
            <div class="Font-24 Montserrat-bold FontChoose">
                Long-Lasting
            </div>
        </section>
    </section>
</section>