<div class="ContainerImage">
    <img class="Img" src="{{$imgSrc}}" alt="Container Image"> 
    <div class="Text"> 
        <div class="Font-24 Montserrat-bold MarginBottom-large LineHeight1">{!!$imgTitle!!}</div>  
        <div class="Font-16 Montserrat LineHeight">{{$imgContent}}</div>
    </div>
</div>