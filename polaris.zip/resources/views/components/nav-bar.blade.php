<div class="NavBar">
    <a href="/"><img class="Logo" src="assets/png/logo.png" alt="Polaris Logo"></a>
    <a class="Desktop Padding MarginRight FontDefault NavBars {{ ( $menu === 'About' )? 'Active' : '' }}" href="/about"> About </a>        
    <a class="Desktop Padding MarginRight FontDefault NavBars {{ ( $menu === 'Service' )? 'Active' : '' }}" href="/service"> Service </a>
    {{-- <a class="Padding MarginRight FontDefault NavBars {{ ( $menu === 'Contact' )? 'Active' : '' }}" href="/contact"> Contact </a> --}}
    <a class="Desktop Padding MarginRight FontDefault NavBars {{ ( $menu === 'Product' )? 'Active' : '' }}" href="/product"> Product </a>

</div>