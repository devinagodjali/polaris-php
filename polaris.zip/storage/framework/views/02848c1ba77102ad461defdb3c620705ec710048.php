<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Polaris Furniture</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NavBar::class, []); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH /home/devina/Desktop/polaris-php/resources/views/welcome.blade.php ENDPATH**/ ?>