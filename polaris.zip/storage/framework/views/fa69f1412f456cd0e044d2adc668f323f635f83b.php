<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Polaris | Service</title>

        <link rel="icon" type="image/png" href="assets/png/favicon.png">
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="styles/container.css">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="BgColor-gray">
        <?php
            $img = '/assets/png/services.png';
            $cardContent = "Do you have your dream furniture? We can make them come true. From the prototyping to execution, don't worry! Just focus on your business.";
            $cardTitle ='<div>Have Something in Mind ? <br/> We Can Make It Happen </div>';
            $tabsTitle = [ 0 => 'OEM', 1 => 'INTERIOR' ];
            $title="Our Services";
            $content= 
            [
                ["title" => "ORIGINAL <br />
                            EQUIPEMENT <br />
                            MANUFACTURE",
                    "text" => 
                    "Do you have your dream chair? Or dream table? We can make your dream chair or dream table or any furniture come true. We can make your design come true.",
                    "image" => "/assets/png/oem.png",
                ], 
                ["title" => "INTERIOR <br/>
                            DESIGN",
                    "text" =>
                    "Need to redecor your room? Or for your business? We provide you the best interior solutions for you. From design to execution, deliver all just in time with the best quality.",
                    "image" => "/assets/png/interior.png",
                ],
            ];
        ?>

        <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NavBar::class, ['menu' => 'Service']); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ContainerWithCard::class, ['imgSrc' => $img,'imgTitle' => $cardTitle,'imgContent' => $cardContent]); ?>
<?php $component->withName('container-with-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php if (isset($__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c)): ?>
<?php $component = $__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c; ?>
<?php unset($__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="Flex JustifyContent-center AlignItems-center MarginTop-2xlarge">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('container-with-tabs', ['containerTitle' => $title,'tabsTitle' => $tabsTitle,'content' => $content])->html();
} elseif ($_instance->childHasBeenRendered('IrLWQvs')) {
    $componentId = $_instance->getRenderedChildComponentId('IrLWQvs');
    $componentTag = $_instance->getRenderedChildComponentTagName('IrLWQvs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IrLWQvs');
} else {
    $response = \Livewire\Livewire::mount('container-with-tabs', ['containerTitle' => $title,'tabsTitle' => $tabsTitle,'content' => $content]);
    $html = $response->html();
    $_instance->logRenderedChild('IrLWQvs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </livewire:container-with-tabs>
        </div>
        <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/service.blade.php ENDPATH**/ ?>