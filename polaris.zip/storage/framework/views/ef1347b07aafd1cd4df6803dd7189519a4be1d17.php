<div class="ContainerTab">
    <div class="Font-24 Montserrat-bold MarginBottom"> <?php echo e($containerTitle); ?></div>
 
    <div class="Tabs Flex JustifyContent-around MarginTop">
         <?php $__currentLoopData = $tabsTitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tabTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div 
             wire:click="getId(<?php echo e($i); ?>)"
             class="Tab Font-18 Montserrat-bold Color-gray <?php echo e(($con === $i) ? 'ActiveTab': ''); ?>">
              <?php echo e($tabTitle); ?> 
             </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>

    <div class="TabsContent">
        <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $contentView): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="TabContent Flex JustifyContent-between <?php echo e(($con === $i) ? 'Show': ''); ?>">
                <div class="MarginTop Width-50">
                    <div class="Font-18 Roboto-bold MarginTop"><?php echo $contentView['title']; ?></div>
                    <div class="Font-14 Roboto MarginTop LineHeight width-60">
                        <?php echo $contentView['text'] ?? ''; ?>

                    </div>
                </div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $contentView): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($contentView['image'] !== ''): ?>
            <div class="TabImagesContainer Width-50 Flex AlignItems-center <?php echo e(($con === $i) ? 'Show': 'Hide'); ?>"> 
                <img class="TabImages" src="<?php echo e($contentView['image']); ?>" alt="About Tab">
            </div>
        <?php else: ?>
            <div class="TabImagesContainer Width-50 Flex AlignItems-center <?php echo e(($con === $i) ? 'Show': 'Hide'); ?>"><?php echo $contentView['map']; ?></div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 </div><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/livewire/container-with-tabs.blade.php ENDPATH**/ ?>