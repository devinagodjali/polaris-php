<div class="ContainerTab">
    
    <div class="Font-24 Montserrat-bold MarginBottom ContainerShow"> <?php echo e($containerTitle); ?></div>
 
    <div class="Tabs Flex JustifyContent-around MarginTop ContainerShow">
         <?php $__currentLoopData = $tabsTitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tabTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div 
             wire:click="getId(<?php echo e($i); ?>)"
             class="Tab Font-18 Montserrat-bold Color-gray <?php echo e(($con === $i) ? 'ActiveTab': ''); ?>">
              <?php echo e($tabTitle); ?> 
             </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>

    <div class="TabsContent ContainerShow Width-100">
        <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $contentView): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="TabContent Flex JustifyContent-between <?php echo e(($con === $i) ? 'Show': ''); ?> Width-40">
                <div class="MarginTop Width-100">
                    <div class="Font-18 Roboto-bold MarginTop"><?php echo $contentView['title']; ?></div>
                    <div class="Font-14 Roboto MarginTop LineHeight">
                        <?php echo $contentView['text'] ?? ''; ?>

                    </div>
                </div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $contentView): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($contentView['image'] !== ''): ?>
            <div class="TabImagesContainer Width-50 Flex AlignItems-center <?php echo e(($con === $i) ? 'Show': 'Hide'); ?> HideMobile"> 
                <img class="TabImages" src="<?php echo e($contentView['image']); ?>" alt="About Tab">
            </div>
        <?php else: ?>
            <div class="TabImagesContainer Width-50 Flex AlignItems-center <?php echo e(($con === $i) ? 'Show': 'Hide'); ?>"
                style="min-width: 100px; width: 680px; height: 380px;">
                <?php echo $contentView['map']; ?>

            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    
    <div class="TitleMobile Montserrat-bold ContainerHide"> 
        <?php echo e($containerTitle); ?>

    </div>
    <div class="ContainerHide">
        <?php if($menu === 'about'): ?>
            <?php $__currentLoopData = $tabsTitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tabTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="TabTitleMobile Roboto-bold"> <?php echo e($tabTitle); ?> </div>
                <?php if($i === 0): ?>
                    <img class="TabImages" src="<?php echo e($content[$i]['image']); ?>" style="width: 100vw;" alt="About Tab">
                    <div class="Roboto-bold" style="padding: 10px; font-size: 12px"> <?php echo e($content[$i]['title']); ?> </div>
                <?php endif; ?>
                <?php if($i !== 2): ?>
                    <div class="Roboto TabTextMobile"> <?php echo $content[$i]['text']; ?> </div>
                <?php endif; ?>
                <?php if($i === 2): ?>
                    <div style="width: 100vw; height: 200px"><?php echo $contentView['map']; ?></div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <?php endif; ?>
        <?php if($menu === 'service'): ?>
            <?php $__currentLoopData = $tabsTitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tabTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="TabTitleMobile Roboto-bold"> <?php echo e($tabTitle); ?> </div>
                <img class="TabImages" src="<?php echo e($content[$i]['image']); ?>" style="width: 100vw;" alt="About Tab">
                <div class="Roboto-bold Br" style="padding: 10px; font-size: 12px"> <?php echo $content[$i]['title']; ?> </div>
                <div class="Roboto TabTextMobile"> <?php echo $content[$i]['text']; ?> </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <?php endif; ?>
    </div>
 </div><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/livewire/container-with-tabs.blade.php ENDPATH**/ ?>