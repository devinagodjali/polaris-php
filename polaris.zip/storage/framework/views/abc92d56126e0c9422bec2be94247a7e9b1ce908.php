<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Polaris | Product</title>

        <!-- Link -->
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="styles/home/home.css">
        <link rel="icon" type="image/png" href="assets/png/favicon.png">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="BgColor-gray">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('nav-bar', ['menu' => 'Product'])->html();
} elseif ($_instance->childHasBeenRendered('t9vjlSD')) {
    $componentId = $_instance->getRenderedChildComponentId('t9vjlSD');
    $componentTag = $_instance->getRenderedChildComponentTagName('t9vjlSD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('t9vjlSD');
} else {
    $response = \Livewire\Livewire::mount('nav-bar', ['menu' => 'Product']);
    $html = $response->html();
    $_instance->logRenderedChild('t9vjlSD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:nav-bar>
        <div class="Flex JustifyContent-center MarginTop-2xlarge">
            <div class="MaintenanceContainer Montserrat-bold Font-54 Flex AlignItems-center JustifyContent-center"> Under Maintenance </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/product.blade.php ENDPATH**/ ?>