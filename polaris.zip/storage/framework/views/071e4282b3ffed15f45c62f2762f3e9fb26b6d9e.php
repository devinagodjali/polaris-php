<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Polaris Furniture</title>

        <!-- Link -->
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="styles/home/home.css">
        <link rel="icon" type="image/png" href="assets/png/favicon.png">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('nav-bar', ['menu' => ''])->html();
} elseif ($_instance->childHasBeenRendered('gQcHK30')) {
    $componentId = $_instance->getRenderedChildComponentId('gQcHK30');
    $componentTag = $_instance->getRenderedChildComponentTagName('gQcHK30');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gQcHK30');
} else {
    $response = \Livewire\Livewire::mount('nav-bar', ['menu' => '']);
    $html = $response->html();
    $_instance->logRenderedChild('gQcHK30', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:nav-bar>

        <section class="HomePage">
            <section class="HomeBanner">
                <div>
                    <img class="HomeBanner-placeholder" src="assets/png/homepage.png" alt="Home Banner PlaceHolder">
                </div>
                <div class="HomeBanner-text">
                    <div class="HomeBanner-text--title">Ergonomis & Kokoh</div>
                    <div class="HomeBanner-text--subTitle" >Polaris Official menjadi pilihan tepat untuk segala kebutuhan Anda.</div>
                </div>
            </section>

            <section class="Flex Flex-column JustifyContent-center">
                <?php if (isset($component)) { $__componentOriginalcf48f276bb170b6dcdb927088a7caca0527842a8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeCategory::class, []); ?>
<?php $component->withName('home-category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalcf48f276bb170b6dcdb927088a7caca0527842a8)): ?>
<?php $component = $__componentOriginalcf48f276bb170b6dcdb927088a7caca0527842a8; ?>
<?php unset($__componentOriginalcf48f276bb170b6dcdb927088a7caca0527842a8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalbea75b79c3572069ca9a9bda89fca7e4fd9936da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeJourney::class, []); ?>
<?php $component->withName('home-journey'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalbea75b79c3572069ca9a9bda89fca7e4fd9936da)): ?>
<?php $component = $__componentOriginalbea75b79c3572069ca9a9bda89fca7e4fd9936da; ?>
<?php unset($__componentOriginalbea75b79c3572069ca9a9bda89fca7e4fd9936da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalcd47f0dbb836c22b72e2c6d0b579229c4cb78243 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeChoosePolaris::class, []); ?>
<?php $component->withName('home-choose-polaris'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalcd47f0dbb836c22b72e2c6d0b579229c4cb78243)): ?>
<?php $component = $__componentOriginalcd47f0dbb836c22b72e2c6d0b579229c4cb78243; ?>
<?php unset($__componentOriginalcd47f0dbb836c22b72e2c6d0b579229c4cb78243); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal5c5ff740de64cbff15f89ae20f232a1f7b77cb78 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeService::class, []); ?>
<?php $component->withName('home-service'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal5c5ff740de64cbff15f89ae20f232a1f7b77cb78)): ?>
<?php $component = $__componentOriginal5c5ff740de64cbff15f89ae20f232a1f7b77cb78; ?>
<?php unset($__componentOriginal5c5ff740de64cbff15f89ae20f232a1f7b77cb78); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </section>

            <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </section>
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH /home/devina/Desktop/polaris-php/resources/views/home.blade.php ENDPATH**/ ?>