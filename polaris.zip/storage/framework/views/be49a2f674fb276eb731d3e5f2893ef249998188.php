<div class="NavBar">
    <divc class="NavMobile Flex JustifyContent-center AlignItems-center">
        <div class="BurgerBar">
            x
        </div>
        <div>
            <a href="/"><img class="LogoMobile" src="assets/png/logo.png" alt="Polaris Logo"></a>
        </div>
    </div>

    <a href="/"><img class="Logo" src="assets/png/logo.png" alt="Polaris Logo"></a>
    <a class="Desktop Padding MarginRight FontDefault NavBars <?php echo e(( $menu === 'About' )? 'Active' : ''); ?>" href="/about"> About </a>        
    <a class="Desktop Padding MarginRight FontDefault NavBars <?php echo e(( $menu === 'Service' )? 'Active' : ''); ?>" href="/service"> Service </a>
    
    <a class="Desktop Padding MarginRight FontDefault NavBars <?php echo e(( $menu === 'Product' )? 'Active' : ''); ?>" href="/product"> Product </a>


    <div class="NabMobile-open">

    </div>
   
</div><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/components/nav-bar.blade.php ENDPATH**/ ?>