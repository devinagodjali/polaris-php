<div class="NavBar">
    <a href="/"><img class="Logo" src="assets/png/logo.png" alt="Polaris Logo"></a>
    <a class="Desktop Padding MarginRight FontDefault NavBars <?php echo e(( $menu === 'About' )? 'Active' : ''); ?>" href="/about"> About </a>        
    <a class="Desktop Padding MarginRight FontDefault NavBars <?php echo e(( $menu === 'Service' )? 'Active' : ''); ?>" href="/service"> Service </a>
    
    <a class="Desktop Padding MarginRight FontDefault NavBars <?php echo e(( $menu === 'Product' )? 'Active' : ''); ?>" href="/product"> Product </a>

</div><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/components/nav-bar.blade.php ENDPATH**/ ?>