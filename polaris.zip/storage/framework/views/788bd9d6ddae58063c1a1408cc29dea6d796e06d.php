<div class="ContainerTab">
   <div class="Font-24 Montserrat-bold MarginBottom"> <?php echo e($title); ?></div>

   <div class="Tabs Flex JustifyContent-around AlignItems-center MarginTop">
        <?php $__currentLoopData = $tabsTitle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tabTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div 
            wire::click="getId"
            class="Tab Font-18 Montserrat-bold">
             <?php echo e($tabTitle); ?> 
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
   </div>
djsfnsdjf
        
   <div class="TabsContent">

   </div>

</div><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/components/container-tab.blade.php ENDPATH**/ ?>