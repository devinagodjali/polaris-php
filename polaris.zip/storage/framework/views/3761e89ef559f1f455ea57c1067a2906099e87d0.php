<div class="ContainerImage">
    <img class="Img" src="<?php echo e($imgSrc); ?>" alt="Container Image"> 
    <div class="Text"> 
        <div class="Font-24 Montserrat-bold MarginBottom-large LineHeight1"><?php echo $imgTitle; ?></div>  
        <div class="Font-16 Montserrat LineHeight"><?php echo e($imgContent); ?></div>
    </div>
</div><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/components/container-with-card.blade.php ENDPATH**/ ?>