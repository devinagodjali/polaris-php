<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Polaris | Contact</title>

        <link rel="icon" type="image/png" href="assets/png/favicon.png">
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="styles/container.css">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="BgColor-gray">
        <?php
            $img = '/assets/png/contact.png';
            $content = "We love to hear from you! For any inquiries or business, we are welcome.";
            $title ='Have Something in Mind?';
        ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('nav-bar', ['menu' => 'Contact'])->html();
} elseif ($_instance->childHasBeenRendered('82AA4Qb')) {
    $componentId = $_instance->getRenderedChildComponentId('82AA4Qb');
    $componentTag = $_instance->getRenderedChildComponentTagName('82AA4Qb');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('82AA4Qb');
} else {
    $response = \Livewire\Livewire::mount('nav-bar', ['menu' => 'Contact']);
    $html = $response->html();
    $_instance->logRenderedChild('82AA4Qb', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:nav-bar>
        <?php if (isset($component)) { $__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ContainerWithCard::class, ['imgSrc' => $img,'imgTitle' => $title,'imgContent' => $content]); ?>
<?php $component->withName('container-with-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php if (isset($__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c)): ?>
<?php $component = $__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c; ?>
<?php unset($__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <div class="Flex JustifyContent-center MarginTop-xlarge">
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-form', [])->html();
} elseif ($_instance->childHasBeenRendered('aXTe6J6')) {
    $componentId = $_instance->getRenderedChildComponentId('aXTe6J6');
    $componentTag = $_instance->getRenderedChildComponentTagName('aXTe6J6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aXTe6J6');
} else {
    $response = \Livewire\Livewire::mount('contact-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('aXTe6J6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-form>
        </div>
        <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/contact.blade.php ENDPATH**/ ?>