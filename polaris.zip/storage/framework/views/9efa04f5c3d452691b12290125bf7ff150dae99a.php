<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contact Page</title>

        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="styles/container.css">
    </head>
    <body>
        <?php
            $img = '/assets/png/contact.png';
            $content = "We love to hear from you! For any inquiries or business, we are welcome.";
            $title ='Have Something in Mind?';
        ?>

        <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\NavBar::class, ['menu' => 'Contact']); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ContainerWithCard::class, ['imgSrc' => $img,'imgTitle' => $title,'imgContent' => $content]); ?>
<?php $component->withName('container-with-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php if (isset($__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c)): ?>
<?php $component = $__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c; ?>
<?php unset($__componentOriginal6c36c8e2bd82db76bd2c2c3c56fd77200dde428c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <section class="PageWithNavBar">
            "Contact"
        </section>
    </body>
</html><?php /**PATH /home/devina/Desktop/polaris-php/resources/views/contact.blade.php ENDPATH**/ ?>